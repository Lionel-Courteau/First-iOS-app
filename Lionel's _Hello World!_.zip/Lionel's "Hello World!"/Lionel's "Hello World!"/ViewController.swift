//
//  ViewController.swift
//  Lionel's "Hello World!"
//
//  Created by Lionel Courteau on 1/17/19.
//  Copyright © 2019 Lionel Courteau. All rights reserved.
//
// 1)

import UIKit

class ViewController: UIViewController {

    @IBAction func Pushbutton(_ sender: UIButton) {
        print("Hello World!")
        let alert = UIAlertController(title: "This is My First App", message: "Hello World!", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

